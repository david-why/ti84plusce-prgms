#ifndef _STDNORETURN_H
#define _STDNORETURN_H

#ifndef __cplusplus

#define noreturn _Noreturn

#endif /* __cplusplus */

#endif /* _STDNORETURN_H */
