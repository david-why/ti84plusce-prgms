### Get TI Token Demo

This demo shows how to use the `ti_GetDataPtr` and `ti_GetTokenString` functions.
It prints out the first two tokens in the basic program `ABC`.

![Screenshot](screenshot.png)

---

This demo is part of the CE C SDK Toolchain.
