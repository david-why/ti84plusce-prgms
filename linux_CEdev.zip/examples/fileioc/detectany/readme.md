### Any File Detection Demo

Uses the `ti_DetectAny` function to search for a variable.
The LibLoad AppVar is used because it is known to exist.

---

This demo is part of the CE C SDK Toolchain.
