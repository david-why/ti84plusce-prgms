### File Detection Demo

Uses the `ti_Detect` function to search for a variable.
The LibLoad AppVar is used because it is known to exist.

---

This demo is part of the CE C SDK Toolchain.
