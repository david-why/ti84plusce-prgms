### File Write/Read Demo

Writes data to a file and then reads back for verification.

---

This demo is part of the CE C SDK Toolchain.
