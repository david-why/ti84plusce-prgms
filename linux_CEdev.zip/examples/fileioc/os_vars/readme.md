### OS Variables Demo

This demo shows how to use the different OS variable accessing functions.

![Screenshot](screenshot.png)

---

This demo is part of the CE C SDK Toolchain.
