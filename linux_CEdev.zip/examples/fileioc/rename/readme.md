### Rename Demo

Renames a previously created file.

---

This demo is part of the CE C SDK Toolchain.
