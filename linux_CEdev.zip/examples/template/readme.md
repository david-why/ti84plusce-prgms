### CE C SDK Template

You can clone this directory for your own projects.

To add code, fill in the `int main(void)` function in main.c. You can also create
your own source and header files and add them to the directory; the makefile
will automatically find and compile the new source files.

---

This template is a part of the C SDK Toolchain for use on the CE.

