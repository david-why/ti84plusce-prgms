### Font Pack Demo

Uses a font pack AppVar instead of directly embedding a font into the binary.

---

This demo is part of the CE C SDK Toolchain.
