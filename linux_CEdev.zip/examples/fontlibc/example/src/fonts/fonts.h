#ifndef FONTS_H
#define FONTS_H

#include <fontlibc.h>

extern const fontlib_font_t *test_font;

#endif
