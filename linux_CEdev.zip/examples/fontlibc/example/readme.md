### Text Demo

Displays text using FontLibC. It shows both using the text window, and using text metrics to help position text.

![Screenshot](screenshot.png)

---

This demo is part of the CE C SDK Toolchain.
