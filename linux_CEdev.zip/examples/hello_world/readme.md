### Hello World Demo

Displays the text `Hello, World!` on the calculator.

---

This demo is part of the CE C SDK Toolchain.
