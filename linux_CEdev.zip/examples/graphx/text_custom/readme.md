### Character Demo

Flips a text string and displays it upside down.

![Screenshot](screenshot.png)

---

This demo is part of the CE C SDK Toolchain.
