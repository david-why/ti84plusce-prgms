#ifndef ubuntu_include_file
#define ubuntu_include_file

#ifdef __cplusplus
extern "C" {
#endif

#define ubuntu_width 32
#define ubuntu_height 32
#define ubuntu_size 1026
#define ubuntu ((gfx_sprite_t*)ubuntu_data)
extern unsigned char ubuntu_data[1026];

#ifdef __cplusplus
}
#endif

#endif
