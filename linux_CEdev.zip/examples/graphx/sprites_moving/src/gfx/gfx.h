#ifndef gfx_include_file
#define gfx_include_file

#ifdef __cplusplus
extern "C" {
#endif

#include "global_palette.h"
#include "ubuntu.h"
#include "oiram.h"

#ifdef __cplusplus
}
#endif

#endif
