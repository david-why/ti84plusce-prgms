### Moving a Sprite

Demonstrates using the graphx and keypadc libraries together to move a sprite.
Sprite incorporates transparency and partial redraw.

![Screenshot](screenshot.png)

---

This demo is part of the CE C SDK Toolchain.
