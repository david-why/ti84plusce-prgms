#ifndef apple_include_file
#define apple_include_file

#ifdef __cplusplus
extern "C" {
#endif

#define apple_width 220
#define apple_height 240
#define apple_size 52802
#define apple_compressed_size 9979
extern unsigned char apple_compressed[9979];

#ifdef __cplusplus
}
#endif

#endif
