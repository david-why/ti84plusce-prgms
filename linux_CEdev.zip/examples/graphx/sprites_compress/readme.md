### Compressed Sprite Demo

Demonstrates compressing a sprite and later decompressing in order to save
storage space.

![Screenshot](screenshot.png)

---

This demo is part of the CE C SDK Toolchain.
