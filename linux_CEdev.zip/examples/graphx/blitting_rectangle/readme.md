### Blitting Rectangles Demo

This example demonstrates blitting to manually copy data from the  hidden drawing buffer to the visible screen buffer.

![Screenshot](screenshot.png)

---

This demo is part of the CE C SDK Toolchain.
