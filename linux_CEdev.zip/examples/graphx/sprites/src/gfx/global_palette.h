#ifndef global_palette_include_file
#define global_palette_include_file

#ifdef __cplusplus
extern "C" {
#endif

#define sizeof_global_palette 30
extern unsigned char global_palette[30];

#ifdef __cplusplus
}
#endif

#endif
