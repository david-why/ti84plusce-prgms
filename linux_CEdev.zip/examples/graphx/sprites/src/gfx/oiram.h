#ifndef oiram_include_file
#define oiram_include_file

#ifdef __cplusplus
extern "C" {
#endif

#define oiram_width 16
#define oiram_height 27
#define oiram_size 434
#define oiram ((gfx_sprite_t*)oiram_data)
extern unsigned char oiram_data[434];

#ifdef __cplusplus
}
#endif

#endif
