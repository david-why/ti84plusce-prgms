#ifndef star_include_file
#define star_include_file

#ifdef __cplusplus
extern "C" {
#endif

#define star_width 48
#define star_height 48
#define star_size 2306
#define star ((gfx_sprite_t*)star_data)
extern unsigned char star_data[2306];

#ifdef __cplusplus
}
#endif

#endif
