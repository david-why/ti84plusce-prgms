### Rotated and Flipped Sprite Demo

Rotates sprites quickly clockwise and counterclockwise, including vertical
and horizontal flips.

![Screenshot](screenshot.png)

---

This demo is part of the CE C SDK Toolchain.
