### Tilemap Appvar Demo

Demonstrates storage of a tileset in an appvar.

![Screenshot](screenshot.png)

---

This demo is part of the CE C SDK Toolchain.
