#ifndef global_palette_include_file
#define global_palette_include_file

#ifdef __cplusplus
extern "C" {
#endif

#define sizeof_global_palette 260
extern unsigned char global_palette[260];

#ifdef __cplusplus
}
#endif

#endif
