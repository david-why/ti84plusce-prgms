#ifndef ubuntu_include_file
#define ubuntu_include_file

#ifdef __cplusplus
extern "C" {
#endif

#define ubuntu_width 31
#define ubuntu_height 30
#define ubuntu_size 537
#define ubuntu ((gfx_rletsprite_t*)ubuntu_data)
extern unsigned char ubuntu_data[537];

#ifdef __cplusplus
}
#endif

#endif
