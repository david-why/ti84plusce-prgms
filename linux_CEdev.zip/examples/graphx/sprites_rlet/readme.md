### RLETSprite Demo

Draws a sprite with RLE transparency in many clipping scenarios and converts to
and from a normal sprite with transparency. Created for testing.

![Screenshot](screenshot.png)

---

This demo is part of the CE C SDK Toolchain.
