### Scaled Text Demo

This example demonstrates alternating the clipping region and using clipped text properly.

![Screenshot](screenshot.png)

---

This demo is part of the CE C SDK Toolchain.
