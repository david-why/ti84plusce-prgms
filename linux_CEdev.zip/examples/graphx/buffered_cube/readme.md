### Cube Buffer Demo

Draws a rotating cube, where drawing is performed on the hidden back buffer.

![Screenshot](screenshot.png)

---

This demo is part of the CE C SDK Toolchain.
