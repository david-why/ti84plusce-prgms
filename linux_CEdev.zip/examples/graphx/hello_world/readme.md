### Graphical Hello World Demo

Prints the text `Hello, World!` centered on the screen.

![Screenshot](screenshot.png)

---

This demo is part of the CE C SDK Toolchain.
