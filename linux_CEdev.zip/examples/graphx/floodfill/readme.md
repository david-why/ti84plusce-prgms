### Flood Fill Demo

Fills a polygon image with a color using the flood fill function.

![Screenshot](screenshot.png)

---

This demo is part of the CE C SDK Toolchain.
