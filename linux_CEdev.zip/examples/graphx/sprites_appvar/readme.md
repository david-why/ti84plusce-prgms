### Sprite AppVar Demo

Demonstrates extracting and using images stored in an AppVar.

![Screenshot](screenshot.png)

---

This demo is part of the CE C SDK Toolchain.
