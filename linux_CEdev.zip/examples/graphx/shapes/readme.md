### GraphX Shapes Demo

Draws different shapes, pixels, text.

![Screenshot](screenshot.png)

---

This demo is a part of the C SDK Toolchain for use on the CE.

