### Lighten and Darken Demo

Uses gfx_Darken and gfx_Lighten to modify palette colors for fading effects.

![Screenshot](screenshot.gif)

---

This demo is part of the CE C SDK Toolchain.
