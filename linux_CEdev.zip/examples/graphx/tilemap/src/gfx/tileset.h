#ifndef tileset_include_file
#define tileset_include_file

#ifdef __cplusplus
extern "C" {
#endif

extern unsigned char tileset_tile_0_data[258];
#define tileset_tile_0 ((gfx_sprite_t*)tileset_tile_0_data)
extern unsigned char tileset_tile_1_data[258];
#define tileset_tile_1 ((gfx_sprite_t*)tileset_tile_1_data)
extern unsigned char tileset_tile_2_data[258];
#define tileset_tile_2 ((gfx_sprite_t*)tileset_tile_2_data)
extern unsigned char tileset_tile_3_data[258];
#define tileset_tile_3 ((gfx_sprite_t*)tileset_tile_3_data)
extern unsigned char tileset_tile_4_data[258];
#define tileset_tile_4 ((gfx_sprite_t*)tileset_tile_4_data)
extern unsigned char tileset_tile_5_data[258];
#define tileset_tile_5 ((gfx_sprite_t*)tileset_tile_5_data)
extern unsigned char tileset_tile_6_data[258];
#define tileset_tile_6 ((gfx_sprite_t*)tileset_tile_6_data)
extern unsigned char tileset_tile_7_data[258];
#define tileset_tile_7 ((gfx_sprite_t*)tileset_tile_7_data)
extern unsigned char tileset_tile_8_data[258];
#define tileset_tile_8 ((gfx_sprite_t*)tileset_tile_8_data)
extern unsigned char tileset_tile_9_data[258];
#define tileset_tile_9 ((gfx_sprite_t*)tileset_tile_9_data)
extern unsigned char tileset_tile_10_data[258];
#define tileset_tile_10 ((gfx_sprite_t*)tileset_tile_10_data)
extern unsigned char tileset_tile_11_data[258];
#define tileset_tile_11 ((gfx_sprite_t*)tileset_tile_11_data)
extern unsigned char tileset_tile_12_data[258];
#define tileset_tile_12 ((gfx_sprite_t*)tileset_tile_12_data)
extern unsigned char tileset_tile_13_data[258];
#define tileset_tile_13 ((gfx_sprite_t*)tileset_tile_13_data)
extern unsigned char tileset_tile_14_data[258];
#define tileset_tile_14 ((gfx_sprite_t*)tileset_tile_14_data)
extern unsigned char tileset_tile_15_data[258];
#define tileset_tile_15 ((gfx_sprite_t*)tileset_tile_15_data)
extern unsigned char tileset_tile_16_data[258];
#define tileset_tile_16 ((gfx_sprite_t*)tileset_tile_16_data)
extern unsigned char tileset_tile_17_data[258];
#define tileset_tile_17 ((gfx_sprite_t*)tileset_tile_17_data)
extern unsigned char tileset_tile_18_data[258];
#define tileset_tile_18 ((gfx_sprite_t*)tileset_tile_18_data)
extern unsigned char tileset_tile_19_data[258];
#define tileset_tile_19 ((gfx_sprite_t*)tileset_tile_19_data)
extern unsigned char tileset_tile_20_data[258];
#define tileset_tile_20 ((gfx_sprite_t*)tileset_tile_20_data)
extern unsigned char tileset_tile_21_data[258];
#define tileset_tile_21 ((gfx_sprite_t*)tileset_tile_21_data)
extern unsigned char tileset_tile_22_data[258];
#define tileset_tile_22 ((gfx_sprite_t*)tileset_tile_22_data)
extern unsigned char tileset_tile_23_data[258];
#define tileset_tile_23 ((gfx_sprite_t*)tileset_tile_23_data)
extern unsigned char tileset_tile_24_data[258];
#define tileset_tile_24 ((gfx_sprite_t*)tileset_tile_24_data)
extern unsigned char tileset_tile_25_data[258];
#define tileset_tile_25 ((gfx_sprite_t*)tileset_tile_25_data)
extern unsigned char tileset_tile_26_data[258];
#define tileset_tile_26 ((gfx_sprite_t*)tileset_tile_26_data)
extern unsigned char tileset_tile_27_data[258];
#define tileset_tile_27 ((gfx_sprite_t*)tileset_tile_27_data)
extern unsigned char tileset_tile_28_data[258];
#define tileset_tile_28 ((gfx_sprite_t*)tileset_tile_28_data)
extern unsigned char tileset_tile_29_data[258];
#define tileset_tile_29 ((gfx_sprite_t*)tileset_tile_29_data)
extern unsigned char tileset_tile_30_data[258];
#define tileset_tile_30 ((gfx_sprite_t*)tileset_tile_30_data)
extern unsigned char tileset_tile_31_data[258];
#define tileset_tile_31 ((gfx_sprite_t*)tileset_tile_31_data)
extern unsigned char tileset_tile_32_data[258];
#define tileset_tile_32 ((gfx_sprite_t*)tileset_tile_32_data)
extern unsigned char tileset_tile_33_data[258];
#define tileset_tile_33 ((gfx_sprite_t*)tileset_tile_33_data)
extern unsigned char tileset_tile_34_data[258];
#define tileset_tile_34 ((gfx_sprite_t*)tileset_tile_34_data)
extern unsigned char tileset_tile_35_data[258];
#define tileset_tile_35 ((gfx_sprite_t*)tileset_tile_35_data)
extern unsigned char tileset_tile_36_data[258];
#define tileset_tile_36 ((gfx_sprite_t*)tileset_tile_36_data)
extern unsigned char tileset_tile_37_data[258];
#define tileset_tile_37 ((gfx_sprite_t*)tileset_tile_37_data)
extern unsigned char tileset_tile_38_data[258];
#define tileset_tile_38 ((gfx_sprite_t*)tileset_tile_38_data)
extern unsigned char tileset_tile_39_data[258];
#define tileset_tile_39 ((gfx_sprite_t*)tileset_tile_39_data)
extern unsigned char tileset_tile_40_data[258];
#define tileset_tile_40 ((gfx_sprite_t*)tileset_tile_40_data)
extern unsigned char tileset_tile_41_data[258];
#define tileset_tile_41 ((gfx_sprite_t*)tileset_tile_41_data)
extern unsigned char tileset_tile_42_data[258];
#define tileset_tile_42 ((gfx_sprite_t*)tileset_tile_42_data)
extern unsigned char tileset_tile_43_data[258];
#define tileset_tile_43 ((gfx_sprite_t*)tileset_tile_43_data)
extern unsigned char tileset_tile_44_data[258];
#define tileset_tile_44 ((gfx_sprite_t*)tileset_tile_44_data)
extern unsigned char tileset_tile_45_data[258];
#define tileset_tile_45 ((gfx_sprite_t*)tileset_tile_45_data)
extern unsigned char tileset_tile_46_data[258];
#define tileset_tile_46 ((gfx_sprite_t*)tileset_tile_46_data)
extern unsigned char tileset_tile_47_data[258];
#define tileset_tile_47 ((gfx_sprite_t*)tileset_tile_47_data)
extern unsigned char tileset_tile_48_data[258];
#define tileset_tile_48 ((gfx_sprite_t*)tileset_tile_48_data)
extern unsigned char tileset_tile_49_data[258];
#define tileset_tile_49 ((gfx_sprite_t*)tileset_tile_49_data)
extern unsigned char tileset_tile_50_data[258];
#define tileset_tile_50 ((gfx_sprite_t*)tileset_tile_50_data)
extern unsigned char tileset_tile_51_data[258];
#define tileset_tile_51 ((gfx_sprite_t*)tileset_tile_51_data)
extern unsigned char tileset_tile_52_data[258];
#define tileset_tile_52 ((gfx_sprite_t*)tileset_tile_52_data)
extern unsigned char tileset_tile_53_data[258];
#define tileset_tile_53 ((gfx_sprite_t*)tileset_tile_53_data)
extern unsigned char tileset_tile_54_data[258];
#define tileset_tile_54 ((gfx_sprite_t*)tileset_tile_54_data)
extern unsigned char tileset_tile_55_data[258];
#define tileset_tile_55 ((gfx_sprite_t*)tileset_tile_55_data)
extern unsigned char tileset_tile_56_data[258];
#define tileset_tile_56 ((gfx_sprite_t*)tileset_tile_56_data)
extern unsigned char tileset_tile_57_data[258];
#define tileset_tile_57 ((gfx_sprite_t*)tileset_tile_57_data)
extern unsigned char tileset_tile_58_data[258];
#define tileset_tile_58 ((gfx_sprite_t*)tileset_tile_58_data)
extern unsigned char tileset_tile_59_data[258];
#define tileset_tile_59 ((gfx_sprite_t*)tileset_tile_59_data)
extern unsigned char tileset_tile_60_data[258];
#define tileset_tile_60 ((gfx_sprite_t*)tileset_tile_60_data)
extern unsigned char tileset_tile_61_data[258];
#define tileset_tile_61 ((gfx_sprite_t*)tileset_tile_61_data)
extern unsigned char tileset_tile_62_data[258];
#define tileset_tile_62 ((gfx_sprite_t*)tileset_tile_62_data)
extern unsigned char tileset_tile_63_data[258];
#define tileset_tile_63 ((gfx_sprite_t*)tileset_tile_63_data)
extern unsigned char tileset_tile_64_data[258];
#define tileset_tile_64 ((gfx_sprite_t*)tileset_tile_64_data)
extern unsigned char tileset_tile_65_data[258];
#define tileset_tile_65 ((gfx_sprite_t*)tileset_tile_65_data)
extern unsigned char tileset_tile_66_data[258];
#define tileset_tile_66 ((gfx_sprite_t*)tileset_tile_66_data)
extern unsigned char tileset_tile_67_data[258];
#define tileset_tile_67 ((gfx_sprite_t*)tileset_tile_67_data)
extern unsigned char tileset_tile_68_data[258];
#define tileset_tile_68 ((gfx_sprite_t*)tileset_tile_68_data)
extern unsigned char tileset_tile_69_data[258];
#define tileset_tile_69 ((gfx_sprite_t*)tileset_tile_69_data)
extern unsigned char tileset_tile_70_data[258];
#define tileset_tile_70 ((gfx_sprite_t*)tileset_tile_70_data)
extern unsigned char tileset_tile_71_data[258];
#define tileset_tile_71 ((gfx_sprite_t*)tileset_tile_71_data)
extern unsigned char tileset_tile_72_data[258];
#define tileset_tile_72 ((gfx_sprite_t*)tileset_tile_72_data)
extern unsigned char tileset_tile_73_data[258];
#define tileset_tile_73 ((gfx_sprite_t*)tileset_tile_73_data)
extern unsigned char tileset_tile_74_data[258];
#define tileset_tile_74 ((gfx_sprite_t*)tileset_tile_74_data)
extern unsigned char tileset_tile_75_data[258];
#define tileset_tile_75 ((gfx_sprite_t*)tileset_tile_75_data)
extern unsigned char tileset_tile_76_data[258];
#define tileset_tile_76 ((gfx_sprite_t*)tileset_tile_76_data)
extern unsigned char tileset_tile_77_data[258];
#define tileset_tile_77 ((gfx_sprite_t*)tileset_tile_77_data)
extern unsigned char tileset_tile_78_data[258];
#define tileset_tile_78 ((gfx_sprite_t*)tileset_tile_78_data)
extern unsigned char tileset_tile_79_data[258];
#define tileset_tile_79 ((gfx_sprite_t*)tileset_tile_79_data)
extern unsigned char tileset_tile_80_data[258];
#define tileset_tile_80 ((gfx_sprite_t*)tileset_tile_80_data)
extern unsigned char tileset_tile_81_data[258];
#define tileset_tile_81 ((gfx_sprite_t*)tileset_tile_81_data)
extern unsigned char tileset_tile_82_data[258];
#define tileset_tile_82 ((gfx_sprite_t*)tileset_tile_82_data)
extern unsigned char tileset_tile_83_data[258];
#define tileset_tile_83 ((gfx_sprite_t*)tileset_tile_83_data)
extern unsigned char tileset_tile_84_data[258];
#define tileset_tile_84 ((gfx_sprite_t*)tileset_tile_84_data)
extern unsigned char tileset_tile_85_data[258];
#define tileset_tile_85 ((gfx_sprite_t*)tileset_tile_85_data)
extern unsigned char tileset_tile_86_data[258];
#define tileset_tile_86 ((gfx_sprite_t*)tileset_tile_86_data)
extern unsigned char tileset_tile_87_data[258];
#define tileset_tile_87 ((gfx_sprite_t*)tileset_tile_87_data)
extern unsigned char tileset_tile_88_data[258];
#define tileset_tile_88 ((gfx_sprite_t*)tileset_tile_88_data)
extern unsigned char tileset_tile_89_data[258];
#define tileset_tile_89 ((gfx_sprite_t*)tileset_tile_89_data)
extern unsigned char tileset_tile_90_data[258];
#define tileset_tile_90 ((gfx_sprite_t*)tileset_tile_90_data)
extern unsigned char tileset_tile_91_data[258];
#define tileset_tile_91 ((gfx_sprite_t*)tileset_tile_91_data)
extern unsigned char tileset_tile_92_data[258];
#define tileset_tile_92 ((gfx_sprite_t*)tileset_tile_92_data)
extern unsigned char tileset_tile_93_data[258];
#define tileset_tile_93 ((gfx_sprite_t*)tileset_tile_93_data)
extern unsigned char tileset_tile_94_data[258];
#define tileset_tile_94 ((gfx_sprite_t*)tileset_tile_94_data)
extern unsigned char tileset_tile_95_data[258];
#define tileset_tile_95 ((gfx_sprite_t*)tileset_tile_95_data)
extern unsigned char tileset_tile_96_data[258];
#define tileset_tile_96 ((gfx_sprite_t*)tileset_tile_96_data)
extern unsigned char tileset_tile_97_data[258];
#define tileset_tile_97 ((gfx_sprite_t*)tileset_tile_97_data)
extern unsigned char tileset_tile_98_data[258];
#define tileset_tile_98 ((gfx_sprite_t*)tileset_tile_98_data)
extern unsigned char tileset_tile_99_data[258];
#define tileset_tile_99 ((gfx_sprite_t*)tileset_tile_99_data)
extern unsigned char tileset_tile_100_data[258];
#define tileset_tile_100 ((gfx_sprite_t*)tileset_tile_100_data)
extern unsigned char tileset_tile_101_data[258];
#define tileset_tile_101 ((gfx_sprite_t*)tileset_tile_101_data)
extern unsigned char tileset_tile_102_data[258];
#define tileset_tile_102 ((gfx_sprite_t*)tileset_tile_102_data)
extern unsigned char tileset_tile_103_data[258];
#define tileset_tile_103 ((gfx_sprite_t*)tileset_tile_103_data)
extern unsigned char tileset_tile_104_data[258];
#define tileset_tile_104 ((gfx_sprite_t*)tileset_tile_104_data)
extern unsigned char tileset_tile_105_data[258];
#define tileset_tile_105 ((gfx_sprite_t*)tileset_tile_105_data)
extern unsigned char tileset_tile_106_data[258];
#define tileset_tile_106 ((gfx_sprite_t*)tileset_tile_106_data)
extern unsigned char tileset_tile_107_data[258];
#define tileset_tile_107 ((gfx_sprite_t*)tileset_tile_107_data)
extern unsigned char tileset_tile_108_data[258];
#define tileset_tile_108 ((gfx_sprite_t*)tileset_tile_108_data)
extern unsigned char tileset_tile_109_data[258];
#define tileset_tile_109 ((gfx_sprite_t*)tileset_tile_109_data)
extern unsigned char tileset_tile_110_data[258];
#define tileset_tile_110 ((gfx_sprite_t*)tileset_tile_110_data)
extern unsigned char tileset_tile_111_data[258];
#define tileset_tile_111 ((gfx_sprite_t*)tileset_tile_111_data)
extern unsigned char tileset_tile_112_data[258];
#define tileset_tile_112 ((gfx_sprite_t*)tileset_tile_112_data)
extern unsigned char tileset_tile_113_data[258];
#define tileset_tile_113 ((gfx_sprite_t*)tileset_tile_113_data)
extern unsigned char tileset_tile_114_data[258];
#define tileset_tile_114 ((gfx_sprite_t*)tileset_tile_114_data)
extern unsigned char tileset_tile_115_data[258];
#define tileset_tile_115 ((gfx_sprite_t*)tileset_tile_115_data)
extern unsigned char tileset_tile_116_data[258];
#define tileset_tile_116 ((gfx_sprite_t*)tileset_tile_116_data)
extern unsigned char tileset_tile_117_data[258];
#define tileset_tile_117 ((gfx_sprite_t*)tileset_tile_117_data)
extern unsigned char tileset_tile_118_data[258];
#define tileset_tile_118 ((gfx_sprite_t*)tileset_tile_118_data)
extern unsigned char tileset_tile_119_data[258];
#define tileset_tile_119 ((gfx_sprite_t*)tileset_tile_119_data)
extern unsigned char tileset_tile_120_data[258];
#define tileset_tile_120 ((gfx_sprite_t*)tileset_tile_120_data)
extern unsigned char tileset_tile_121_data[258];
#define tileset_tile_121 ((gfx_sprite_t*)tileset_tile_121_data)
extern unsigned char tileset_tile_122_data[258];
#define tileset_tile_122 ((gfx_sprite_t*)tileset_tile_122_data)
extern unsigned char tileset_tile_123_data[258];
#define tileset_tile_123 ((gfx_sprite_t*)tileset_tile_123_data)
extern unsigned char tileset_tile_124_data[258];
#define tileset_tile_124 ((gfx_sprite_t*)tileset_tile_124_data)
extern unsigned char tileset_tile_125_data[258];
#define tileset_tile_125 ((gfx_sprite_t*)tileset_tile_125_data)
extern unsigned char tileset_tile_126_data[258];
#define tileset_tile_126 ((gfx_sprite_t*)tileset_tile_126_data)
extern unsigned char tileset_tile_127_data[258];
#define tileset_tile_127 ((gfx_sprite_t*)tileset_tile_127_data)
#define tileset_num_tiles 128
extern unsigned char *tileset_tiles_data[128];
#define tileset_tiles ((gfx_sprite_t**)tileset_tiles_data)

#ifdef __cplusplus
}
#endif

#endif
