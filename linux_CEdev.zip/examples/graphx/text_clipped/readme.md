### Text Clipping Demo

This example how to do text clipping by bouncing a string around a fixed box.

![Screenshot](screenshot.png)

---

This demo is part of the CE C SDK Toolchain.
