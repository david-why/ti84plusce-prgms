### Fullscreen AppVar Image Demo

Uses a compressed tiled image in an AppVar to construct a fullscreen image.

![Screenshot](screenshot.png)

---

This demo is part of the CE C SDK Toolchain.
