### Rotation and Scaling Sprite Demo

Rotates and scales a sprite directly to the screen.

![Screenshot](screenshot.png)

---

This demo is part of the CE C SDK Toolchain.
