### Graphics Template

You can clone this directory for your own graphx-based projects.

To add code, fill in the begin, end, step, and draw functions in main.c.

---

This demo is part of the CE C SDK Toolchain.
