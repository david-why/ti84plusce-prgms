### ti::real usage (C++ demo)

Interacts with the toolchain's C++ class wrapping TI's Real number format.
This format is already accessible in C via the real_t struct provided in tice.h

---

This demo is part of the CE C SDK Toolchain.
