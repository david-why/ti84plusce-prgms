### Delay Demo

Demonstrates using the millisecond delay function in tice.h.

---

This demo is part of the CE C SDK Toolchain.
