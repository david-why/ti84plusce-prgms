### Second Counter 2 Demo

Uses the hardware timers to make a simple second counter a different way.

![Screenshot](screenshot.gif)

---

This demo is part of the CE C SDK Toolchain.
