### LCD Fade Demo

Controls the LCD backlight by fading in and out.

---

This demo is part of the CE C SDK Toolchain.
