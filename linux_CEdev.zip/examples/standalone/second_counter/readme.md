### Second Counter Demo

Uses the hardware timers to make a simple second counter.

---

This demo is part of the CE C SDK Toolchain.
