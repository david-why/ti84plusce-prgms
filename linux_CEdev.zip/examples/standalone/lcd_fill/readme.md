### Fill Screen Demo

Fills the screen with a single color.

![Screenshot](screenshot.gif)

---

This demo is part of the CE C SDK Toolchain.
