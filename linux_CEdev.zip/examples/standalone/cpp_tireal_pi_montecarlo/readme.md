### ti::real pi estimation (C++ demo)

This uses the Monte Carlo method to estimate pi.

As expected, it is very slow. You can quit by pressing a key at any time.
You can also just run it in CEmu, unthrottled, where it takes around 30s. 

---

This demo is part of the CE C SDK Toolchain.
