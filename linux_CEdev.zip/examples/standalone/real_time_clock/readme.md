### Real Time Clock Demo

Demonstrates the basics of the real time clock (RTC).

![Screenshot](screenshot.gif)

---

This demo is part of the CE C SDK Toolchain.
