### Args Demo

Demonstrates using argc and argv.

---

This demo is part of the CE C SDK Toolchain.
