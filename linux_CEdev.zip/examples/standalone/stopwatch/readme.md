### Stopwatch Demo

This demo demonstrates using the hardware timers to make a simple stopwatch
displaying millisecond precision.

![Screenshot](screenshot.png)

---

This demo is part of the CE C SDK Toolchain.
