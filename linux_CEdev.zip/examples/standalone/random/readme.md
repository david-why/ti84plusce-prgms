### Random Fill Screen Demo

Fills the screen with random colors.

![Screenshot](screenshot.png)

---

This demo is part of the CE C SDK Toolchain.
