### Keypad Arrow Key Demo

Changes the color of the screen depending on which arrow keys are pressed.

![Screenshot](screenshot.gif)

---

This demo is part of the CE C SDK Toolchain.
