### Multiple Keypad Keys Demo

This demo shows how to register multiple keypresses at the same time.

![Screenshot](screenshot.gif)

---

This demo is part of the CE C SDK Toolchain.
